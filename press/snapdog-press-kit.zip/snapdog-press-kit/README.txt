SnapDog press kit

SnapDog is a native macOS menu-bar app for screenshots, screen recording, and annotation — with OCR, QR tools, on-device transcription, workflows, and built-in upload destinations. $14.99 one-time, available now on the Mac App Store.

Price: $14.99 one-time on the Mac App Store
Requires: macOS 14.0 or later
Current version: 1.2.1 (September 25, 2026)
App Store: https://apps.apple.com/us/app/snapdog-capture-annotate/id6783121166?mt=12
Publisher: Remnant Security Group LLC
Press contact: iantrimble@remnantsecurity.com

SnapDog by Remnant Security is not affiliated with snapdog.app.
